package com.ualr.simpletasklist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.ualr.simpletasklist.databinding.ActivityMainBinding;
import com.ualr.simpletasklist.model.TaskList;

import java.util.Arrays;


public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();
    private ActivityMainBinding binding;
    private TaskList tasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.tasks = new TaskList();
    }

    public void onAddBtnClicked(View v) {
        String task = binding.editTextTextPersonName.getText().toString();
        tasks.add(task);

        binding.editTextTextPersonName.setText("");
        binding.taskList.setText(tasks.toString());

    }

    public void onDeleteBtnClicked(View v) {
        try {
            Integer taskId = Integer.parseInt(binding.editTextTaskId.getText().toString());
            tasks.delete(taskId);
            binding.editTextTaskId.setText("");

            if (tasks.getTasks().size() == 0) {
                binding.taskList.setText(R.string.task_list_empty);
            }
            else {
                binding.taskList.setText(tasks.toString());
            }
        }
        catch (Exception e) {
            Log.d(TAG, Arrays.toString(e.getStackTrace()));
        }
    }

    public void onDoneBtnClicked(View v) {
        try {
            Integer taskId = Integer.parseInt(binding.editTextTaskId.getText().toString());
            tasks.markDone(taskId);

            binding.editTextTaskId.setText("");
            binding.taskList.setText(tasks.toString());
        }
        catch (Exception e) {
            Log.d(TAG, Arrays.toString(e.getStackTrace()));
        }
    }
}